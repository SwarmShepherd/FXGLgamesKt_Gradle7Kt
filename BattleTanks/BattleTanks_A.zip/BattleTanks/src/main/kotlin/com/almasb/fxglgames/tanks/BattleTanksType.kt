package com.almasb.fxglgames.tanks

/**
 * @author Almas Baimagambetov (almaslvl@gmail.com)
 */
enum class BattleTanksType {
    BULLET, WALL, FLAG
}